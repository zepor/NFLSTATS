#!/bin/bash
tmux kill-session -t gridiron
