#!/bin/bash
tmux new-session -d -s gridiron 'python3 app.py'
